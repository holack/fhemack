var customConfig = {
	plotRefresh:  120
}
