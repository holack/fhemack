For installation details, have a look at

http://www.fhemwiki.de/wiki/Neues_Charting_Frontend

The ExtJS Library as well as the application itself are available under the GPLv3 License. See the license.txt in the lib folder for details
